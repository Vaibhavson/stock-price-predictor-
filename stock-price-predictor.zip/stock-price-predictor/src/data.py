"""Data loading: yfinance -> local CSV -> synthetic fallback (offline demo)."""
import numpy as np
import pandas as pd


def load_from_yfinance(ticker: str, period: str = "5y") -> pd.DataFrame:
    import yfinance as yf
    df = yf.download(ticker, period=period, auto_adjust=True, progress=False)
    if df is None or df.empty:
        raise RuntimeError(f"No data returned for {ticker}")
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df[["Open", "High", "Low", "Close", "Volume"]].dropna()


def load_from_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["Date"], index_col="Date").sort_index()
    need = {"Open", "High", "Low", "Close", "Volume"}
    if not need.issubset(df.columns):
        raise ValueError(f"CSV must contain columns: {sorted(need)}")
    return df[["Open", "High", "Low", "Close", "Volume"]].dropna()


def make_synthetic(n_days: int = 1500, seed: int = 42) -> pd.DataFrame:
    """Geometric Brownian motion with drift + volatility clustering.
    ONLY for offline demo/testing - not real market data."""
    rng = np.random.default_rng(seed)
    vol = np.empty(n_days)
    vol[0] = 0.012
    for i in range(1, n_days):
        vol[i] = 0.000002 + 0.85 * vol[i - 1] + 0.15 * abs(rng.normal(0, 0.012))
    ret = 0.0004 + vol * rng.normal(size=n_days)
    close = 100 * np.exp(np.cumsum(ret))
    open_ = close * (1 + rng.normal(0, 0.003, n_days))
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.004, n_days)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.004, n_days)))
    volume = rng.integers(1_000_000, 5_000_000, n_days)
    idx = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=n_days)
    return pd.DataFrame({"Open": open_, "High": high, "Low": low,
                         "Close": close, "Volume": volume}, index=idx)


def get_data(ticker="AAPL", period="5y", csv=None, allow_synthetic=True):
    """Returns (df, source_label)."""
    if csv:
        return load_from_csv(csv), f"csv:{csv}"
    try:
        return load_from_yfinance(ticker, period), f"yfinance:{ticker}"
    except Exception as e:  # network blocked, bad ticker, etc.
        if not allow_synthetic:
            raise
        print(f"[warn] Could not fetch {ticker} ({type(e).__name__}). "
              f"Using SYNTHETIC data - results are for demo only.")
        return make_synthetic(), "synthetic"
