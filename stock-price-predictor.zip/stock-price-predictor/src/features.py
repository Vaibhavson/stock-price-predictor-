"""Technical-indicator feature engineering. All features use only past data."""
import numpy as np
import pandas as pd


def rsi(close: pd.Series, n: int = 14) -> pd.Series:
    d = close.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    c, v = df["Close"], df["Volume"]
    f = pd.DataFrame(index=df.index)
    f["ret_1"] = c.pct_change()
    for k in (2, 5, 10, 20):
        f[f"ret_{k}"] = c.pct_change(k)
    for lag in range(1, 6):
        f[f"ret_lag{lag}"] = f["ret_1"].shift(lag)
    for w in (5, 10, 20, 50):
        f[f"sma_ratio_{w}"] = c / c.rolling(w).mean() - 1
    for w in (12, 26):
        f[f"ema_ratio_{w}"] = c / c.ewm(span=w, adjust=False).mean() - 1
    macd = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    f["macd"] = macd / c
    f["macd_signal"] = macd.ewm(span=9, adjust=False).mean() / c
    f["rsi_14"] = rsi(c, 14)
    ma20, sd20 = c.rolling(20).mean(), c.rolling(20).std()
    f["bb_pos"] = (c - (ma20 - 2 * sd20)) / (4 * sd20)
    f["vol_10"] = f["ret_1"].rolling(10).std()
    f["vol_20"] = f["ret_1"].rolling(20).std()
    f["hl_range"] = (df["High"] - df["Low"]) / c
    f["oc_change"] = (df["Close"] - df["Open"]) / df["Open"]
    f["volume_ratio"] = v / v.rolling(20).mean()
    return f


def make_dataset(df: pd.DataFrame):
    """X_t -> target = next-day return. Returns X, y_ret, close (aligned)."""
    X = build_features(df)
    y = df["Close"].pct_change().shift(-1)  # tomorrow's return
    data = pd.concat([X, y.rename("target")], axis=1)
    data["close"] = df["Close"]
    last_row = X.iloc[[-1]].copy()          # for the real "tomorrow" forecast
    data = data.dropna()
    return data.drop(columns=["target", "close"]), data["target"], data["close"], last_row
