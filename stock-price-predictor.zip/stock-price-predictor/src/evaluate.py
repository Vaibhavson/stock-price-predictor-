import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def price_metrics(close_t, actual_ret, pred_ret):
    """Convert predicted returns to next-day prices and score them."""
    close_t = np.asarray(close_t)
    actual_price = close_t * (1 + np.asarray(actual_ret))
    pred_price = close_t * (1 + np.asarray(pred_ret))
    dir_acc = np.mean(np.sign(pred_ret) == np.sign(actual_ret))
    return {
        "RMSE": float(np.sqrt(mean_squared_error(actual_price, pred_price))),
        "MAE": float(mean_absolute_error(actual_price, pred_price)),
        "R2_price": float(r2_score(actual_price, pred_price)),
        "R2_return": float(r2_score(actual_ret, pred_ret)),
        "DirAcc": float(dir_acc),
    }
