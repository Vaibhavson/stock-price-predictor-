# Stock Price Predictor

Predicts the **next trading day's close** from historical OHLCV data.

## Pipeline
1. **Data** – `yfinance` (any ticker) → or your own CSV (`Date,Open,High,Low,Close,Volume`) → or synthetic data (offline demo only).
2. **Features** (`src/features.py`) – returns, lagged returns, SMA/EMA ratios, MACD, RSI, Bollinger position, volatility, volume ratio. Only past data is used (no look-ahead).
3. **Target** – next-day *return*, converted back to a price.
4. **Models** – Linear Regression, Ridge, Random Forest, Gradient Boosting.
5. **Validation** – chronological 80/20 split (no shuffling) + walk-forward `TimeSeriesSplit` CV.
6. **Metrics** – RMSE, MAE, R² (price & return), directional accuracy, vs. a **naive baseline** (tomorrow = today).
7. **Outputs** – `outputs/results.csv`, `predictions.png`, `feature_importance.png`, `best_model.joblib`, plus a next-day forecast.

## Run
```bash
pip install -r requirements.txt
python main.py --ticker AAPL --period 5y     # real data (needs internet)
python main.py --csv prices.csv              # your own data
python main.py                               # offline demo (synthetic data)
```

## Honest notes
- Price R² looks ~0.98 for *every* model, including the naive baseline, because prices are autocorrelated. Judge models by **RMSE vs baseline** and **directional accuracy** (~50% = coin flip).
- The demo in `outputs/` used **synthetic random-walk data** (sandbox had no Yahoo access), so no model can beat the baseline there – that is expected. Run with a real ticker for real results.
- Educational project, not financial advice.
