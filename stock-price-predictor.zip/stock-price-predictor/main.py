"""Stock Price Predictor - train, compare, plot, and forecast next trading day.

Examples:
  python main.py --ticker AAPL --period 5y
  python main.py --csv my_prices.csv
  python main.py                      # offline demo with synthetic data
"""
import argparse
import os

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit

from src.data import get_data
from src.evaluate import price_metrics
from src.features import make_dataset
from src.models import get_models


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticker", default="AAPL")
    ap.add_argument("--period", default="5y")
    ap.add_argument("--csv", default=None, help="CSV with Date,Open,High,Low,Close,Volume")
    ap.add_argument("--test-size", type=float, default=0.2)
    ap.add_argument("--out", default="outputs")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    df, source = get_data(a.ticker, a.period, a.csv)
    print(f"Data source: {source} | rows: {len(df)} | {df.index[0].date()} -> {df.index[-1].date()}")

    X, y, close, last_row = make_dataset(df)
    split = int(len(X) * (1 - a.test_size))           # chronological split, NO shuffling
    Xtr, Xte, ytr, yte = X.iloc[:split], X.iloc[split:], y.iloc[:split], y.iloc[split:]
    ctr, cte = close.iloc[:split], close.iloc[split:]
    print(f"Train: {len(Xtr)} days | Test: {len(Xte)} days")

    rows, preds, fitted = [], {}, {}
    # Baseline: "tomorrow = today" (predicted return = 0). Any model must beat this.
    base = price_metrics(cte, yte, np.zeros(len(yte)))
    rows.append({"Model": "Baseline (naive)", **base})

    tscv = TimeSeriesSplit(n_splits=5)
    for name, model in get_models().items():
        # walk-forward CV on the training window (directional accuracy)
        cv = []
        for tr, va in tscv.split(Xtr):
            model.fit(Xtr.iloc[tr], ytr.iloc[tr])
            cv.append(np.mean(np.sign(model.predict(Xtr.iloc[va])) == np.sign(ytr.iloc[va])))
        model.fit(Xtr, ytr)
        p = model.predict(Xte)
        preds[name], fitted[name] = p, model
        rows.append({"Model": name, **price_metrics(cte, yte, p), "CV_DirAcc": float(np.mean(cv))})

    res = pd.DataFrame(rows).set_index("Model").round(4)
    print("\n=== Test-set results (next-day prediction) ===")
    print(res.to_string())
    res.to_csv(f"{a.out}/results.csv")

    best = res.drop("Baseline (naive)")["RMSE"].idxmin()
    print(f"\nBest model by RMSE: {best}")

    # ---- Plots ----
    actual_price = cte.values * (1 + yte.values)
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(yte.index, actual_price, label="Actual", lw=1.6, color="black")
    for name, p in preds.items():
        ax.plot(yte.index, cte.values * (1 + p), label=name, lw=1, alpha=.8)
    ax.set_title(f"Next-day close: actual vs predicted ({source})")
    ax.legend(); ax.grid(alpha=.3); fig.tight_layout()
    fig.savefig(f"{a.out}/predictions.png", dpi=130); plt.close(fig)

    m = fitted["Random Forest"]
    imp = pd.Series(m.feature_importances_, index=X.columns).nlargest(12)[::-1]
    fig, ax = plt.subplots(figsize=(7, 5)); imp.plot.barh(ax=ax)
    ax.set_title("Top features (Random Forest)"); fig.tight_layout()
    fig.savefig(f"{a.out}/feature_importance.png", dpi=130); plt.close(fig)

    # ---- Refit best on ALL data, forecast tomorrow, save model ----
    final = get_models()[best].fit(X, y)
    ret_pred = float(final.predict(last_row)[0])
    last_close = float(df["Close"].iloc[-1])
    print(f"\nLast close: {last_close:.2f} | forecast next close: {last_close*(1+ret_pred):.2f} "
          f"({ret_pred*100:+.2f}%)")
    joblib.dump({"model": final, "features": list(X.columns), "name": best}, f"{a.out}/best_model.joblib")
    print(f"Saved: {a.out}/results.csv, predictions.png, feature_importance.png, best_model.joblib")
    print("\nNOTE: Educational project. Markets are near-efficient; do not trade real money on this.")


if __name__ == "__main__":
    main()
